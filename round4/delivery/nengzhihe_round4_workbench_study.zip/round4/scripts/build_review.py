"""Assemble offline evidence review; no live diagnosis is simulated in this page."""
from pathlib import Path
import json,shutil,sys,hashlib,html
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from policies import run_case
from followup import prioritize
import reporter
def main():
 dest=ROOT/'delivery/review';dest.mkdir(parents=True,exist_ok=True)
 def copy(src,name):shutil.copy2(ROOT/src,dest/name)
 copy('video/final/nengzhihe_actual_operation_3min.mp4','demo.mp4')
 copy('video/final/recording_provenance.json','recording_provenance.json')
 for i,name in enumerate(['项目简表','项目说明书','商业计划书'],1):
  for ext in ['pdf','docx']:copy(f'materials/final/附件{i}_能智核_{name}.{ext}',f'attachment{i}.{ext}')
 for ext in ['pdf','pptx']:copy(f'presentation/final/能智核_实际核查任务答辩.{ext}',f'presentation.{ext}')
 for name in ['summary.json','base_case_results.csv','by_date.json','set_overlap.json']:copy('output/comparison/'+name,name)
 copy('output/ui/workbench_top.png','workbench.png');copy('REPORT.txt','report.txt')
 copy('study/README.txt','study_protocol.txt')
 copy('output/examples/video_import_card.html','import_card.html')
 c=json.loads((ROOT/'data/demos/NZH-76889C2BA896.json').read_text(encoding='utf8'))
 r=prioritize(run_case(c,'full_information',4,repair=True,save=False));assert r['final']['label']=='damper_stuck'
 (dest/'suspicion_card.html').write_text(reporter.card(r),encoding='utf8')
 links=''.join(f'<a href="attachment{i}.pdf">{name} PDF</a><a class="edit" href="attachment{i}.docx">编辑 DOCX</a>' for i,name in enumerate(['项目简表 · 3页','项目说明书 · 5页','商业计划书 · 3页'],1))
 page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>能智核 · 阶段评审</title><style>
*{box-sizing:border-box}body{margin:0;background:#f4f7f4;color:#173c36;font-family:"Microsoft YaHei",sans-serif;line-height:1.65}header{background:#173c36;color:white;padding:56px max(5vw,24px)}main{max-width:1140px;margin:auto;padding:28px 24px}h1{font-size:36px;line-height:1.4;margin:10px 0}h2{font-size:25px}p{max-width:920px}.eyebrow{font-size:13px;letter-spacing:3px;color:#c9dbb5}.grid{display:grid;grid-template-columns:1fr 1fr;gap:24px}.panel{background:white;border:1px solid #dce5dd;border-radius:12px;padding:25px;margin:22px 0}a{color:#175b4a}nav a,.links a{display:inline-block;border:1px solid #aac6b7;padding:9px 15px;border-radius:5px;margin:6px 8px 6px 0;text-decoration:none}.edit{font-size:13px}video{width:100%;max-height:730px;background:#173c36}table{border-collapse:collapse;width:100%}th,td{text-align:left;border-bottom:1px solid #dce5dd;padding:12px}th{background:#e8f0e9}.notice{border-left:4px solid #a47d30;padding:8px 16px;background:#f7f5e9}.small{font-size:14px;color:#5f726b}img{width:100%}@media(max-width:750px){.grid{display:block}h1{font-size:28px}}</style>
<header><div class="eyebrow">智慧能源与环境 · 公开数据原型 · 阶段评审</div><h1>能智核<br>公共建筑风阀疑点核验与补证工作台</h1><p>告警之后，先查什么？从原始CSV开始，核对数据、辨明当前工况、交接下一步补证动作。</p><nav><a style="color:white" href="#video">看实际操作</a><a style="color:white" href="presentation.pdf">看10页答辩稿</a><a style="color:white" href="#evidence">看真实结果</a></nav></header>
<main><p class="notice">本页无需安装、可离线阅读。它展示实际录制与导出证据，不在页面内模拟算法重算。真人价值实验尚待独立复核与招募，当前0名参与者。</p>
<section class="panel" id="video"><h2>三分钟 · 完成一次实际核查</h2><video controls preload="metadata" poster="workbench.png"><source src="demo.mp4" type="video/mp4"></video><p class="small">实际浏览器操作截图采样，字幕说明，无配音；录制段之间空等已剪除，操作顺序保留。不作为响应时间或人工提效测量。<a href="recording_provenance.json">录制来源与章节</a></p></section>
<div class="grid"><section class="panel"><h2>01 从CSV到核查卡</h2><p>确认字段、单位与真实采样间隔。错误间隔声明拒绝；1440行一分钟数据显式转为288条记录，导出本次结果与数据哈希。</p><div class="links"><a href="import_card.html">打开实际导入核查卡</a></div><p class="small">April10开发示例；有限正常结论不代表历史正常类召回。</p></section><section class="panel"><h2>02 数据修好，疑点仍在</h2><p>删除12条完全重复记录后，记录检查通过，风阀候选保留。继续核对测点、温差及执行器；未发现偏离不等于排除卡滞。</p><div class="links"><a href="suspicion_card.html">打开修正后核查卡</a></div></section></div>
<section class="panel" id="evidence"><h2>历史56个基础日工况：没有新增性能优势</h2><table><tr><th>源工况设置</th><th>基础数</th><th>一致候选</th><th>未决</th></tr><tr><td>正常</td><td>14</td><td>0</td><td>14</td></tr><tr><td>卡滞开度25%（025）</td><td>14</td><td>1</td><td>13</td></tr><tr><td>卡滞开度75%（075）</td><td>14</td><td>11</td><td>3</td></tr><tr><td>盘管阀泄漏</td><td>14</td><td>0</td><td>14</td></tr><tr><th>合计</th><th>56</th><th>12</th><th>44</th></tr></table><p>工作台、固定温差阈值、去连续窗口约束消融三者都是同一12个候选。14个日期、2个日期块、1套仿真系统。未决计入分母；025/075是卡滞开度，不是轻重等级。</p><p>112条为56组原始/重复记录扰动，三方法各0组候选标签变化。正常与盘管泄漏三分类召回仍为0。本轮没有新留出成绩，不主张零误报、算法领先或自适应提效。</p><div class="links"><a href="base_case_results.csv">基础工况逐例表</a><a href="summary.json">原始汇总</a><a href="by_date.json">日期分组</a><a href="set_overlap.json">候选集合核对</a></div></section>
<section class="panel"><h2>已准备真人价值对照，待实施</h2><p>A：常规曲线/表格＋检查清单。B：相同数据与检查清单＋工作台。8个匹配不重复任务，4种交叉平衡顺序；记录时间、证据遗漏、错误归因、超时失败及背景。答案和评分先由独立人员逐题复核，再由团队招募5—10人。</p><p class="notice">当前0名参与者，参考答案尚未独立签署，正式入口锁定。软件演练不计入真人成绩，没有已验证的人工提效或节能收益。</p><a href="study_protocol.txt">主持与邀测流程</a></section>
<section class="panel"><h2>材料与可编辑原件</h2><p>三份Word按官方章节、限字与匿名要求制作，共11页；答辩稿10页。均已逐页视觉复检。身份字段留空，成熟度仅自评第3级；这些是参赛底稿，不表示报名手续完成。</p><div class="links"><a href="presentation.pdf">10页答辩 PDF</a><a class="edit" href="presentation.pptx">编辑 PPTX</a>LINKS</div><a href="report.txt">完整交付与限制说明</a></section><p class="small">BDG2实测仅用能回放；LBNL用于仿真核验；人为重复扰动单独标注。真实楼宇适用性、真人价值和节能收益仍待验证。</p></main></html>'''
 (dest/'index.html').write_text(page.replace('LINKS',links),encoding='utf8')
 hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.iterdir() if p.is_file() and p.name!='manifest.json'}
 (dest/'manifest.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2),encoding='utf8')
 print('Offline review files:',len(hashes))
if __name__=='__main__':main()
